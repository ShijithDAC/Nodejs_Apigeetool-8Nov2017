const express = require('express');
const app = express();
let arr = [];
app.get('/', function (req, res) {
  res.json('Hello World!');
});
app.get('/hello_new',function(req,res){
    res.json("Welcome New user");
});
app.post("/add",function(req,res){
    let test= req.body.name;
    console.log(test);
    res.json(test);
});
app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});